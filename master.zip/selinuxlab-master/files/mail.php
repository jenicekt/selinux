<?php
mail('root@localhost', 'Test', 'This is a testmessage');
?>
